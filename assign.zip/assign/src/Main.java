public class Main {
public static void main(String[] args) {
 Account account = new Account(1122,200000,4.5);{
     account.withdraw(2500);
     account.deposit(3000);
     System.out.println("the current balance is: "+ account.getBalance());
     System.out.println("the current monthly intrest rate:"+ account.getMonthlyIntrestRate());
     System.out.println("current date:"+ account.getDateCreated());






    }
 }
}









