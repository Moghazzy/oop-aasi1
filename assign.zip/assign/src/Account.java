import java.util.Date;

public class Account {
    private int id = 0;
    private double balance = 0;
    private double annualIntrestRate =0;
    private Date dateCreated;

    public Account() {

    }

    public Account(int id,double balance,double annualIntrestRate) {
        this.id = id;
        this.balance = balance;
        this.annualIntrestRate=annualIntrestRate;
    }



    public int getId() {
        return id;
    }

    public double getBalance() {
        return balance;
    }

    public double getAnnualIntrestRate() {
        return annualIntrestRate;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void setAnnualIntrestRate(double annualIntrestRate) {
        this.annualIntrestRate = annualIntrestRate;
    }
    public double getMonthlyIntrestRate(){
        return (annualIntrestRate/12);
    }
    public double getMonthlyIntrest(){
        return (balance * getMonthlyIntrestRate());
    }
        public void withdraw(double amount)
        {
            balance-=amount;
        }
        public void deposit (double amount){
        balance+=amount;
        }
}